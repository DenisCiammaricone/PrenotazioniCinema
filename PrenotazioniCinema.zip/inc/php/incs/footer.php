<footer class="text-light pr-4 Opacizable pagina" style="clear:both;">
    <div class="card-deck text-center">

        <div class="card dark-footer" style="width:20vw;">

          <div class="card-body">
              <p class="card-text">CopyRight @2019</p>
          </div>

        </div>

        <div class="card dark-footer" style="width:20vw;">

              <div class="card-body">
                  <p class="card-text">Classe 5AI IIS "Alessandrini-Teramo"</p>
              </div>

        </div>

        <div class="card dark-footer" style="width:20vw;">

              <div class="card-body" id="DivAutori">
                  
                  <p class="card-text">
                        <a href="#" class="text-white" id="AutoriBtn"><u>Autori</u></a>
                  </p>
                    
                  <div class="text-white card" id="AutoriDropUp">
                       <i>Ciammaricone Denis</i><br>
                       <i>Di Simone Andrea Luca</i><br>
                       <i>Lotorio Luca</i><br>
                       <i>Stortini Corrado</i><br>
                       <i>Tupitti Leonardo</i><br>
                       <i>Vetuschi Luigi</i>
                  </div>
            </div>
        </div>

    </div>
</footer>