<footer class="text-light pt-2 pr-4 Opacizable pagina" style="clear:both;">
    <div class="card-deck text-center">

        <div class="card dark-footer" style="width:20vw;">

          <div class="card-body">
              <p class="card-text">CopyRight @2019</p>
          </div>

        </div>

        <div class="card dark-footer" style="width:20vw;">

              <div class="card-body">
                  <p class="card-text">Giusto per prova</p>
              </div>

        </div>

        <div class="card dark-footer" style="width:20vw;">

              <div class="card-body">
                  <p class="card-text"><b>Made by</b><br>
                        <i>Ciammaricone Denis</i><br>
                        <i>Di Simone Andrea</i><br>
                        <i>Lotorio Luca</i><br>
                        <i>Stortini Corrado</i><br>
                        <i>Tupitti Leonardo</i><br>
                        <i>Vetuschi Luigi</i>
                  </p>
              </div>

        </div>

    </div>
</footer>